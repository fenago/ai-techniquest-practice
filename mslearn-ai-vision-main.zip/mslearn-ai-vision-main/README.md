# mslearn-ai-vision
Lab files for Azure AI Vision modules
